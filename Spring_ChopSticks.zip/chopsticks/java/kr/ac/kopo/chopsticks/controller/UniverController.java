package kr.ac.kopo.chopsticks.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.kopo.chopsticks.dao.UniverDao;
import kr.ac.kopo.chopsticks.dao.UserDao;
import kr.ac.kopo.chopsticks.model.User;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.univer;
import kr.ac.kopo.chopsticks.service.UniverService;
import kr.ac.kopo.chopsticks.service.UserService;
import kr.ac.kopo.chopsticks.util.Pager;
import kr.ac.kopo.chopsticks.util.Pager2;

@Controller
@RequestMapping("/univer")
public class UniverController {
	final String path = "univer/";
//	final String uploadpath = "d://upload//";
	final String uploadpath = "/home/team5/upload";
	@Autowired
	UniverService service;
	UserDao dao;
	@RequestMapping(value = "/univer")
	String list(Model model, Pager pager) {
		
		List<univer> list = service.list(pager);
		model.addAttribute("list", list);
		model.addAttribute("pager", pager);
		return path + "univer";
	}

	@RequestMapping(value = "/delete")
	String delete(int uid) {
		service.delete(uid);

		return "redirect:univer";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	String add() {

		return path + "add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	String add(univer item) {
		
	      if (item.getAttach1() != null && item.getAttach2() != null && item.getAttach3() != null && item.getAttach4() != null) {
	         String filename = item.getAttach1().getOriginalFilename();
	         String filename2 = item.getAttach2().getOriginalFilename();
	         String filename3 = item.getAttach3().getOriginalFilename();
	         String filename4 = item.getAttach4().getOriginalFilename();
	         try {
	            item.getAttach1().transferTo(new File(uploadpath + filename));
	            item.getAttach2().transferTo(new File(uploadpath + filename2));
	            item.getAttach3().transferTo(new File(uploadpath + filename3));
	            item.getAttach4().transferTo(new File(uploadpath + filename4));

	            item.setFilename(filename);
	            item.setFilename2(filename2);
	            item.setFilename3(filename3);
	            item.setFilename4(filename4);
	         } catch (IllegalStateException e) {
	            e.printStackTrace();
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	      }
	      
	      service.add(item);
	      
		return "redirect:univer";
	}

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	String update(int uid, Model model) {
		univer item = service.item(uid);

		model.addAttribute("item", item);

		return path+"update";
	}
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	String update(univer item, Model model) {
		
		service.update(item);
		model.addAttribute("item", item);
		
		
		return "redirect:univer";
	} 
	
	@RequestMapping(value="/univerView", method = RequestMethod.GET)
	String view(Model model,int uid) {
		univer item = service.item(uid);
		model.addAttribute("item", item);
		
		List<reply> list = service.replylist(uid); 
		model.addAttribute("reply", list);
		
//		service.replyDelete(rid);
		return path + "univerView"; 
	}
	
	@RequestMapping(value="/univerView", method = RequestMethod.POST)
	String view (reply r, Model model, HttpSession session, int uid) {
		 univer item = service.item(uid);
		 model.addAttribute("item", item);
		 
		 r.setId((String) session.getAttribute("user"));
		 service.replyAdd(r);
		 System.out.println("댓글 성공");
		 
		return "redirect:univerView?uid=" + r.getUid();
	}
	@RequestMapping(value="/univerViewAdd", method = RequestMethod.GET)
	String univerViewAdd(int uid, Model model, User user) {
		univer item = service.item(uid);
		 model.addAttribute("item", item);
		 
		return path + "univerViewAdd";
	}
	
	@RequestMapping(value="/univerViewAdd", method = RequestMethod.POST)
	String univerViewAdd(reply r, HttpSession session, Model model, int uid) {
		 univer item = service.item(uid);
		 model.addAttribute("item", item);
		 
		 r.setId((String) session.getAttribute("user"));
		 service.replyAdd(r);
		 
		return "redirect:univerView?uid=" + r.getUid();
	}
	@RequestMapping("/univerViewReviewDelete")
	String univerViewReviewDelete(int rid, int uid) {
		
		
		 service.replyDelete(rid);
		 
		return "redirect:univerView?uid=" + uid;
	}
}
