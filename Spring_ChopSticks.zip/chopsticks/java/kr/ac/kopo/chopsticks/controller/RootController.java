package kr.ac.kopo.chopsticks.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.ac.kopo.chopsticks.dao.BoardDao;
import kr.ac.kopo.chopsticks.dao.TodayDao;
import kr.ac.kopo.chopsticks.model.Post;
import kr.ac.kopo.chopsticks.model.Today;
import kr.ac.kopo.chopsticks.model.User;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.univer;
import kr.ac.kopo.chopsticks.service.UniverService;
import kr.ac.kopo.chopsticks.service.UserService;
import kr.ac.kopo.chopsticks.util.Pager;

@Controller
@RequestMapping(value="/")
public class RootController {
//	final String uploadpath = "d://upload//";
	final String uploadpath = "/home/team5/upload/";
	@Autowired
	UserService userService;
	@Autowired
	BoardDao dao;
	@Autowired
	UniverService service;
	@Autowired
	TodayDao tDao;
	@RequestMapping("/")
	String main() {
		return "main1"; 
		
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	String login() {
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	String login(User user, HttpSession session) {
		if (userService.login(user)) {
			session.setAttribute("user", user.getId());
			System.out.println("로그인 성공");
			return "redirect:.";
		} else {
			System.out.println("로그인 실패");
		}

		return "redirect:.";
	}
	@RequestMapping("/idcheck")
	@ResponseBody//ajax사용하기 위해 어노테이션 달아주고 
	String idcheck(String id){
		
		int count = userService.idcheck(id);
		
		
		return String.valueOf(count);
	}

	@RequestMapping("/logout")
	String logout(HttpSession session) {
		session.invalidate();
		System.out.println("로그아웃");
		return "main1";
	} 
	@RequestMapping("/brand")
	String brand(HttpSession session, User user) {
		
		return "brand";
	}
	@RequestMapping(value="/today", method = RequestMethod.GET)
	String today(Model model,Pager pager, HttpSession session) {
		List<reply> list = service.replylist2(pager);
		model.addAttribute("reply", list);
		model.addAttribute("pager", pager);
		
		List<Today> list2 = tDao.todaylist();
		model.addAttribute("list2", list2);
		
//		Today item = tDao.item(tid);
//		model.addAttribute("item", item);
		return "today";
	}
	@RequestMapping(value="/today", method = RequestMethod.POST)
	String today(reply r, Model model, HttpSession session, Today today) {
		service.replyAdd2(r);
		return "redirect:today";
	}
	@RequestMapping(value="/todayReviewAdd", method = RequestMethod.GET)
	String todayReviewAdd(Model model) {
//		Today item = tDao.item(tid);
//		model.addAttribute("item", item);
		
//		List<Today> list = tDao.todaylist();
//		model.addAttribute("list", list);
		return "todayReviewAdd";
	}
	@RequestMapping(value="/todayReviewAdd", method = RequestMethod.POST)
	String todayReviewAdd(reply r, HttpSession session) {
		r.setId((String) session.getAttribute("user"));
		tDao.todayReviewAdd(r);
		return "redirect:today";
	}
	
	@RequestMapping(value="/todayAdd", method = RequestMethod.GET)
	String todayAdd() {
		
		return "todayAdd";
	}
	
	@RequestMapping(value="/todayAdd", method = RequestMethod.POST)
	String todayAdd(Model model, HttpSession session, Today today) {
		if (today.getAttach1() != null && today.getAttach2() != null && today.getAttach3() != null && today.getAttach4() != null) {
	         String filename1 = today.getAttach1().getOriginalFilename();
	         String filename2 = today.getAttach2().getOriginalFilename();
	         String filename3 = today.getAttach3().getOriginalFilename();
	         String filename4 = today.getAttach4().getOriginalFilename();
	         try {
	        	 today.getAttach1().transferTo(new File(uploadpath + filename1));
	        	 today.getAttach2().transferTo(new File(uploadpath + filename2));
	        	 today.getAttach3().transferTo(new File(uploadpath + filename3));
	        	 today.getAttach4().transferTo(new File(uploadpath + filename4));

	        	 today.setFilename1(filename1);
	        	 today.setFilename2(filename2);
	        	 today.setFilename3(filename3);
	        	 today.setFilename4(filename4);
	         } catch (IllegalStateException e) {
	            e.printStackTrace();
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	      }
		
		today.setId((String) session.getAttribute("user"));
		tDao.todayAdd(today);
		return "redirect:today";
	}
	@RequestMapping("/todayDelete")
	String todayDelete() throws Exception  {
		tDao.todayDelete();
		return "redirect:today";
	}
	@RequestMapping("/todayReplyDelete")
	String todayReplyDelete(int rid) {
		tDao.todayReplyDelete(rid);
		return "redirect:today";
	}
}
