package kr.ac.kopo.chopsticks.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.kopo.chopsticks.dao.UserDao;
import kr.ac.kopo.chopsticks.model.Post;
import kr.ac.kopo.chopsticks.model.User;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.replyList;

@Controller
@RequestMapping(value="/user")
public class UserController {
//	  final String uploadpath = "d://upload//";
	  final String uploadpath = "/home/team5/upload/";
	@Autowired
	UserDao dao;
	//회원가입 GET
	@RequestMapping("/add")
	String add() {
		
		return "user/add";
	}
	@RequestMapping("/delete")
	String delete(String id, User item, Model model, HttpSession session) {
		item.setId((String)session.getAttribute("user"));
		dao.delete(id);
		model.addAttribute("item", item);
		session.invalidate();
		return "redirect:..";
	}
	//회원가입
	@RequestMapping(value="/useradd", method=RequestMethod.POST)
	String userAdd(Model model,User item) {
		dao.add(item);
		 model.addAttribute("item", item);
		return "redirect:..";
	}
	
	//마이페이지로 jsp를 리턴해주는 리퀘스트 맵핑
	@RequestMapping(value="/mypage",method=RequestMethod.GET)
	String myPage(Model model, HttpSession session) {
		//id 변수 선언해서 세션에 값을 가져와서 item 메소드에 id를 던진다.
		String id= ((String)session.getAttribute("user"));
		User item = dao.item(id);
		
		model.addAttribute("item", item);
		
		return "/user/mypage";
	}
	@RequestMapping(value="/mypage",method=RequestMethod.POST)
	String myPage(Model model,User item, HttpSession session) {
		if (item.getAttach() != null) {
	         String filename = item.getAttach().getOriginalFilename();

	         try {
	            item.getAttach().transferTo(new File(uploadpath + filename));

	            item.setFilename(filename);
	         } catch (IllegalStateException e) {
	            e.printStackTrace();
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	      }
		  item.setId((String)session.getAttribute("user"));
	      dao.update2(item);
	      model.addAttribute("item", item);
		return "redirect:mypage";
	}
	// 비밀번호 변경
	@RequestMapping(value="/passwordUpdate",method=RequestMethod.GET )
	String passwordUpdate(String id, Model model, User user) {
		 List<User> list = dao.list(user);
		User item = dao.item(id);
		model.addAttribute("item", item);
		model.addAttribute("list", list);
	    
		return "/user/passwordUpdate";
	}
	
	@RequestMapping(value="/passwordUpdate", method=RequestMethod.POST)
	String passwordUpdate(User item, HttpSession session) {
		 dao.update(item);
		 
		 session.invalidate();
		return "redirect:..";
	}
	@RequestMapping("/reviewlist")
	String reviewlist(reply r, HttpSession session, Model model) {
		
		r.setId((String)session.getAttribute("user"));
		List<reply> list = dao.reviewList(r);
		model.addAttribute("list", list);
		//유저아이디 값 가져와서 리스트로 넘긴다까지 했다 이제 dao에 reviewList메소드 오버라이드 하면 된다.
		
		return "/user/reviewlist";
	}
}
