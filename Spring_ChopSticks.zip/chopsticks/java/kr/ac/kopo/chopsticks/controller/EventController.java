package kr.ac.kopo.chopsticks.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.kopo.chopsticks.model.event;
import kr.ac.kopo.chopsticks.service.EventService;
import kr.ac.kopo.chopsticks.util.Pager;

@Controller
@RequestMapping("/event")
public class EventController {

final String path ="event/";
	
@Autowired
	EventService service;

	@RequestMapping("/event")
	String eventList(Model model,Pager pager) {
		List<event> list = service.list(pager);
		model.addAttribute("list", list);
		return path + "event";
	}
	
	@RequestMapping(value="/eventAdd", method=RequestMethod.GET)
	String eventAdd() {
		
		return path+ "eventAdd";
	}
	
	@RequestMapping(value="/eventAdd", method=RequestMethod.POST)
	String eventAdd(event e) {
		service.add(e);
		return "redirect:event";
	}
	
	@RequestMapping("/eventDelete")
	String eventDelete(int code){
		service.delete(code);
		return"redirect:event";
	}
	
	@RequestMapping(value="/evenetUpdate", method = RequestMethod.GET)
	String eventUpdate(Model model,int code) {
		event item = service.item(code);
		model.addAttribute("item", item);
		return path + "eventUpdate";
	}
	
	@RequestMapping(value="/evenetUpdate", method = RequestMethod.POST)
	String eventUpdate(int code) {
		service.update(code);
		return "redirect:.";
	}
	
}
