package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.univer;
import kr.ac.kopo.chopsticks.util.Pager;
import kr.ac.kopo.chopsticks.util.Pager2;

public interface UniverDao {

	List<univer> list(Pager pager);

	void delete(int uid);

	void add(univer item);

	univer item(int uid);

	int getTotal(Pager pager);
	
	int getTotal2(Pager pager);

	void update(univer item);

	void replyAdd(reply r);

	List<reply> replylist(int uid);

	void replyDelete(int rid);

	List<reply> replylist2(Pager pager);

	void replyAdd2(reply r);

	int getTotal3(Pager pager);

	


	

}
