package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import kr.ac.kopo.chopsticks.model.User;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.replyList;

public interface UserDao {

	List<User> list(User user);

	void add(User item);

	User item(String id);

	void update(User item);

	void delete(String id);

	boolean login(User user);

	void add2(User item);

	void update2(User item);

	List<reply> reviewList(reply r);

	List<User> list();

	int idck(String id);

	




}
