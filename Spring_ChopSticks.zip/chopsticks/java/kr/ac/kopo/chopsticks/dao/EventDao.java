package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import kr.ac.kopo.chopsticks.model.event;
import kr.ac.kopo.chopsticks.util.Pager;

public interface EventDao {

	int getTotal(Pager pager);

	List<event> list(Pager pager);

	void add(event e);

	void delete(int code);

	void item(int code);

	void update(int code);

}
