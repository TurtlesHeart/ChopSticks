package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.chopsticks.model.Post;
import kr.ac.kopo.chopsticks.util.Pager;
@Repository
public class BoardDaoImpl implements BoardDao {
@Autowired

SqlSession sql;
	
	@Override
	public List<Post> list(Pager pager) {
		return sql.selectList("board.list", pager);
	}

	@Override
	public Post item(long code) {
		return sql.selectOne("board.item",code);
	}
//	
	@Override
	public int getTotal(Pager pager) {		
		return sql.selectOne("board.getTotal", pager);
	}

	@Override
	public void add(Post item) {
		sql.insert("board.add",item);
	}

	@Override
	public void update(Post item) {
		sql.update("board.update",item);
	}

	@Override
	public void delete(long code) {
		sql.delete("board.delete",code);
	}

	@Override
	public void incRef(long code) {
		sql.update("board.incRef", code);
	}

	@Override
	public void incgood(long code) {
		sql.update("board.incgood", code);
	}

	@Override
	public List<Post> list() {
		sql.selectList("board.noticeList");
		return null;
	}
	

}
