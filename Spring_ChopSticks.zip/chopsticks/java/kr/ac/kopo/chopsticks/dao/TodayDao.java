package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import kr.ac.kopo.chopsticks.model.Today;
import kr.ac.kopo.chopsticks.model.reply;



public interface TodayDao {

	List<Today> todaylist();

	void todayAdd(Today today);

	void todayDelete();

	void todayReplyDelete(int rid);

	Today item(int tid);

	void todayReviewAdd(reply r);

	


	

	

}
