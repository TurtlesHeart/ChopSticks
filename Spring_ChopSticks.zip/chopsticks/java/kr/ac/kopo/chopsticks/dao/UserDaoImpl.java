package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.chopsticks.model.User;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.replyList;
@Repository
public class UserDaoImpl implements UserDao {
	
@Autowired
SqlSession sql;

//	@Override
//	public List<User> list() {
//		return sql.selectList("user.list");
//	}

	@Override
	public void add(User item) {
		sql.insert("user.add", item);
	}

	@Override
	public User item(String id) {
		return sql.selectOne("user.item",id);
	}

	@Override
	public void update(User item) {
		sql.update("user.update", item);
	}

	@Override
	public void delete(String id) {
		sql.delete("user.delete",id);
	}

	@Override
	public boolean login(User user) {
		if(sql.selectOne("user.login", user) == null)
		return false;
		
	return true;
	}

	@Override
	public List<User> list(User user) {
		return sql.selectList("user.list", user);
	}

	@Override
	public void add2(User item) {
		sql.update("user.update", item);
	}

	@Override
	public void update2(User item) {
		sql.update("user.update2",item);
	}

	@Override
	public List<reply> reviewList(reply r) {
		return sql.selectList("univer.reviewList", r);
	}

	@Override
	public List<User> list() {
		return sql.selectList("user.list");
	}

	@Override
	public int idck(String id) {
		return sql.selectOne("user.idck",id);
	}



	
	

//	@Override
//	public void add2(User item) {
//		sql.insert("user.profile", item);
//	}


}
