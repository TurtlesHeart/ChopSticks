package kr.ac.kopo.chopsticks.dao;

import java.io.IOException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.chopsticks.model.Today;
import kr.ac.kopo.chopsticks.model.reply;
@Repository
public class TodayDaoImpl implements TodayDao  {
@Autowired
SqlSession sql;
	@Override
	public List<Today> todaylist() {
		
		return sql.selectList("today.list");
	}
	@Override
	public void todayAdd(Today today) {
		sql.insert("today.add", today);
	}
	@Override
	public void todayDelete()  {
		sql.delete("today.delete");	
	}
	@Override
	public void todayReplyDelete(int rid) {
		sql.delete("today.replyDelete", rid);
	}
	@Override
	public Today item(int tid) {
		return sql.selectOne("today.item", tid);
	}
	@Override
	public void todayReviewAdd(reply r) {
		sql.insert("today.reviewAdd", r);
	}
	


}
