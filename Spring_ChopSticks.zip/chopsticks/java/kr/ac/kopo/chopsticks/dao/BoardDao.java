package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import kr.ac.kopo.chopsticks.model.Post;
import kr.ac.kopo.chopsticks.util.Pager;

public interface BoardDao {


	Post item(long code);

	void add(Post item);

	void update(Post item);

	void delete(long code);

	void incRef(long code);

	void incgood(long code);

	List<Post> list(Pager pager);

	int getTotal(Pager pager);

	List<Post> list();
	
}
