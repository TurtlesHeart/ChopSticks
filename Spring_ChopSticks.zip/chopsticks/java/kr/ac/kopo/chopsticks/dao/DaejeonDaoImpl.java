package kr.ac.kopo.chopsticks.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.chopsticks.model.daejeon;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.util.Pager;
@Repository
public class DaejeonDaoImpl implements DaejeonDao {
@Autowired
SqlSession sql;

	@Override
	public int getTotal(Pager pager) {
		return sql.selectOne("daejeon.getTotal", pager);
	}

	@Override
	public List<daejeon> daejeonList(Pager pager) {
		return sql.selectList("daejeon.list", pager);
	}

	@Override
	public void daejeonDelete(int did) {
			sql.delete("daejeon.delete", did);
	}

	@Override
	public void daejeonAdd(daejeon item) {
			sql.insert("daejeon.add", item);
	}

	@Override
	public daejeon daejeonItem() {
		return sql.selectOne("daejeon.item");
	}

	@Override
	public void daejeonUpdate(daejeon item) {
			sql.update("daejeon.update", item);
	}

	@Override
	public List<reply> daejeonReplyList(int did) {
		return sql.selectList("daejeon.replylist", did);
	}

	@Override
	public daejeon item(int did) {
		return sql.selectOne("daejeon.item", did);
	}

	@Override
	public void daejeonReplyAdd(reply r) {
		sql.insert("daejeon.replyAdd", r);
	}

	@Override
	public void daejeonReplyDelete(int rid) {
		sql.delete("daejeon.replyDelete", rid);
		
	} 

}
