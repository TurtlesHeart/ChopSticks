package kr.ac.kopo.chopsticks.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.univer;
import kr.ac.kopo.chopsticks.util.Pager;
import kr.ac.kopo.chopsticks.util.Pager2;
@Repository
public class UniverDaoImpl implements UniverDao {
@Autowired
SqlSession sql;
	 
	@Override
	public List<univer> list(Pager pager) {
		return sql.selectList("univer.list", pager);
	}

	@Override
	public void delete(int uid) {
		sql.delete("univer.delete", uid);
	}

	@Override
	public void add(univer item) {
		sql.insert("univer.add", item);
	}

	@Override
	public univer item(int uid) {
		return sql.selectOne("univer.item",uid);
	}

	@Override
	public int getTotal(Pager pager) {
		return sql.selectOne("univer.getTotal", pager);
	}
	@Override
	public int getTotal2(Pager pager) {
		return sql.selectOne("univer.getTotal2", pager);
	}

	@Override
	public void update(univer item) {
		sql.update("univer.update", item);
	}

	@Override
	public void replyAdd(reply r) {
		sql.insert("univer.replyAdd1", r);
	}

	@Override
	public List<reply> replylist(int uid ) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("uid", uid);
		
		return sql.selectList("univer.replylist", map);
	}

	@Override
	public void replyDelete(int rid) {
		sql.delete("univer.replyDelete", rid);
	}

	@Override
	public List<reply> replylist2(Pager pager) {
		return sql.selectList("univer.replylist2", pager);
	}

	@Override
	public void replyAdd2(reply r) {
		sql.insert("univer.replyAdd2",r);
	}

	@Override
	public int getTotal3(Pager pager) {
		
		return sql.selectOne("univer.getTotal3", pager);
	}



}
