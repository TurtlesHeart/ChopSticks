package kr.ac.kopo.chopsticks.service;

import kr.ac.kopo.chopsticks.model.User;

public interface UserService {

	boolean login(User user);

	int idcheck(String id);

	

}
