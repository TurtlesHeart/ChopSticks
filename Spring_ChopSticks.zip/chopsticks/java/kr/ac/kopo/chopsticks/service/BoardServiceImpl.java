package kr.ac.kopo.chopsticks.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.ac.kopo.chopsticks.dao.BoardDao;
import kr.ac.kopo.chopsticks.model.Post;
import kr.ac.kopo.chopsticks.util.Pager;
@Service

public class BoardServiceImpl implements BoardService {
	@Autowired
	BoardDao dao;

	@Override
	public List<Post> list(Pager pager) {
		
		int total = dao.getTotal(pager);
		
		pager.setTotal(total);                        
		
		return dao.list(pager);
	}

	@Override
	public void add(Post item) {
		dao.add(item);
	}

	@Override
	public Post item(long code) {
		return dao.item(code);
	}

	@Override
	public void update(Post item) {
		 dao.update(item);
	}

	@Override
	public void delete(long code) {
		dao.delete(code);
	}

	@Override
	public void incRef(long code) {
		dao.incRef(code);
	}

	@Override
	public void incgood(long code) {
		dao.incgood(code);
	}

}
