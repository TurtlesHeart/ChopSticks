package kr.ac.kopo.chopsticks.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.chopsticks.dao.UniverDao;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.univer;
import kr.ac.kopo.chopsticks.util.Pager;
import kr.ac.kopo.chopsticks.util.Pager2;
@Service
public class UniverServiceImpl implements UniverService {
@Autowired
UniverDao dao;

	@Override
	public List<univer> list(Pager pager) {
	
		int total = dao.getTotal(pager);
		
		pager.setTotal(total);                        
		
		return dao.list(pager);
	}

	@Override
	public void delete(int uid) {
		dao.delete(uid);
	}

	@Override
	public void add(univer item) {
		dao.add(item);
	}

	@Override
	public univer item(int uid) {
		return dao.item(uid);
	}

	@Override
	public void update(univer item) {
		dao.update(item);
	}

	@Override
	public void replyAdd(reply r) {
		dao.replyAdd(r);
	}
 
	@Override
	public List<reply> replylist(int uid) {
		
		
		return dao.replylist(uid);
	}

	@Override
	public void replyDelete(int rid) {
		dao.replyDelete(rid);
	}

	@Override
	public List<reply>replylist2(Pager pager) {
		int total = dao.getTotal3(pager);
		
		pager.setTotal(total);  
		return dao.replylist2(pager);
	}

	@Override
	public void replyAdd2(reply r) {
		dao.replyAdd2(r);
	}

	


}
