package kr.ac.kopo.chopsticks.service;

import java.util.List;

import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.model.univer;
import kr.ac.kopo.chopsticks.util.Pager;
import kr.ac.kopo.chopsticks.util.Pager2;

public interface UniverService {

	List<univer> list(Pager pager);

	void delete(int uid);

	void add(univer item);

	univer item(int uid);

	void update(univer item);

	void replyAdd(reply r);

	List<reply> replylist(int uid);

	void replyDelete(int rid);

	List<reply> replylist2(Pager pager);

	void replyAdd2(reply r);




}
