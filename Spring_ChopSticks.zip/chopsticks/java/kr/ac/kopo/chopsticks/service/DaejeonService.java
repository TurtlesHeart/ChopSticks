package kr.ac.kopo.chopsticks.service;

import java.util.List;

import kr.ac.kopo.chopsticks.model.daejeon;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.util.Pager;

public interface DaejeonService {

	List<daejeon> daejeonList(Pager pager);

	void daejeonDelete(int did);

	void daejeonAdd(daejeon item);

	daejeon item();

	void daejeonUpdate(daejeon item);

	List<reply> daejeonReplyList(int did);

	daejeon item(int did);

	void daejeonReplyAdd(reply r);

	void replyDelete(int did);

}
