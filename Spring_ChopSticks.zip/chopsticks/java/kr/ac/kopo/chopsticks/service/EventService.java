package kr.ac.kopo.chopsticks.service;

import java.util.List;

import kr.ac.kopo.chopsticks.model.event;
import kr.ac.kopo.chopsticks.util.Pager;

public interface EventService {

	List<event> list(Pager pager);

	void add(event e);

	void delete(int code);

	event item(int code);

	void update(int code);

}
