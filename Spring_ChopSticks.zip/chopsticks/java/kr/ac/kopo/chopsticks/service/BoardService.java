package kr.ac.kopo.chopsticks.service;

import java.util.List;

import kr.ac.kopo.chopsticks.model.Post;
import kr.ac.kopo.chopsticks.util.Pager;

public interface BoardService {


	void add(Post item);

	Post item(long code);

	void update(Post item);

	void delete(long code);

	void incRef(long code);

	void incgood(long code);

	List<Post> list(Pager pager);

}
