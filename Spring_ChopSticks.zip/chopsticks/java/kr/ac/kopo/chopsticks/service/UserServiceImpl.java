package kr.ac.kopo.chopsticks.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.chopsticks.dao.UserDao;
import kr.ac.kopo.chopsticks.model.User;
@Service
public class UserServiceImpl implements UserService {
@Autowired
UserDao dao;
	@Override
	public boolean login(User user) {
		return dao.login(user);
	}
	@Override
	public int idcheck(String id) {
		return dao.idck(id);
	}


}
