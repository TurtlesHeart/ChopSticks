package kr.ac.kopo.chopsticks.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.chopsticks.dao.DaejeonDao;
import kr.ac.kopo.chopsticks.model.daejeon;
import kr.ac.kopo.chopsticks.model.reply;
import kr.ac.kopo.chopsticks.util.Pager;
@Service
public class DaejeonServiceImpl implements DaejeonService {

@Autowired
DaejeonDao dao;
	@Override
	public List<daejeon> daejeonList(Pager pager) {
		int total = dao.getTotal(pager);
		
		pager.setTotal(total);           
		return dao.daejeonList(pager);
	}

	@Override
	public void daejeonDelete(int did) {
		dao.daejeonDelete(did);
	}

	@Override
	public void daejeonAdd(daejeon item) {
		dao.daejeonAdd(item);
	}

	@Override
	public daejeon item() {
		return dao.daejeonItem();
	}

	@Override
	public void daejeonUpdate(daejeon item) {
		dao.daejeonUpdate(item);
	}

	@Override
	public List<reply> daejeonReplyList(int did) {
		return dao.daejeonReplyList(did);
	}

	@Override
	public daejeon item(int did) {
		return dao.item(did);
	}

	@Override
	public void daejeonReplyAdd(reply r) {
		dao.daejeonReplyAdd(r);
	}

	@Override
	public void replyDelete(int rid) {
		dao.daejeonReplyDelete(rid);
	}

}
