package kr.ac.kopo.chopsticks.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.chopsticks.dao.EventDao;
import kr.ac.kopo.chopsticks.model.event;
import kr.ac.kopo.chopsticks.util.Pager;
@Service
public class EventServiceImpl implements EventService {
	@Autowired
	EventDao dao;
	
	@Override
	public List<event> list(Pager pager) {

		int total = dao.getTotal(pager);
		
		pager.setTotal(total); 
		return dao.list(pager);
	}

	@Override
	public void add(event e) {
		dao.add(e);
	}

	@Override
	public void delete(int code) {
		dao.delete(code);
	}

	@Override
	public event item(int code) {
		dao.item(code);
		return null;
	}

	@Override
	public void update(int code) {
		dao.update(code);
	}

}
