package kr.ac.kopo.chopsticks.model;

import org.springframework.web.multipart.MultipartFile;

public class Today {
	int tid;
	String id;
	String menu;
	String contents;
	String filename1;
	String filename2;
	String filename3;
	String filename4;
	
	MultipartFile attach1;
	MultipartFile attach2;
	MultipartFile attach3;
	MultipartFile attach4;
	
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public MultipartFile getAttach1() {
		return attach1;
	}
	public void setAttach1(MultipartFile attach1) {
		this.attach1 = attach1;
	}
	
	public MultipartFile getAttach2() {
		return attach2;
	}
	public void setAttach2(MultipartFile attach2) {
		this.attach2 = attach2;
	}
	public MultipartFile getAttach3() {
		return attach3;
	}
	public void setAttach3(MultipartFile attach3) {
		this.attach3 = attach3;
	}
	public MultipartFile getAttach4() {
		return attach4;
	}
	public void setAttach4(MultipartFile attach4) {
		this.attach4 = attach4;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getFilename1() {
		return filename1;
	}
	public void setFilename1(String filename1) {
		this.filename1 = filename1;
	}
	public String getFilename2() {
		return filename2;
	}
	public void setFilename2(String filename2) {
		this.filename2 = filename2;
	}
	public String getFilename3() {
		return filename3;
	}
	public void setFilename3(String filename3) {
		this.filename3 = filename3;
	}
	public String getFilename4() {
		return filename4;
	}
	public void setFilename4(String filename4) {
		this.filename4 = filename4;
	}
	
	
}
