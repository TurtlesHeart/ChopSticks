package kr.ac.kopo.chopsticks.model;

public class replyList {
		String contents;
		int rid;
		String id;
		int uid;
		int did;
		String title;
		String jinwoo;
		String a;

		public String getJinwoo() {
			return jinwoo;
		}
		public void setJinwoo(String jinwoo) {
			this.jinwoo = jinwoo;
		}
		public String getA() {
			return a;
		}
		public void setA(String a) {
			this.a = a;
		}
		public int getDid() {
			return did;
		}
		public void setDid(int did) {
			this.did = did;
		}
		public String getContents() {
			return contents;
		}
		public void setContents(String contents) {
			this.contents = contents;
		}
		public int getRid() {
			return rid;
		}
		public void setRid(int rid) {
			this.rid = rid;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public int getUid() {
			return uid;
		}
		public void setUid(int uid) {
			this.uid = uid;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
	
		
		
}
