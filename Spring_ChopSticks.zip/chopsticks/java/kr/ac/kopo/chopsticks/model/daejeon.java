package kr.ac.kopo.chopsticks.model;

import org.springframework.web.multipart.MultipartFile;

public class daejeon {
	int did;
	String title;
	String daddress;
	String dtel;
	String filename;
	String dtime;
	String price;
	String grade;
	String filename2;
	String filename3;
	String filename4;
	
	
	MultipartFile attach1;
	MultipartFile attach2;
	MultipartFile attach3;
	MultipartFile attach4;
	
	
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDaddress() {
		return daddress;
	}
	public void setDaddress(String daddress) {
		this.daddress = daddress;
	}
	public String getDtel() {
		return dtel;
	}
	public void setDtel(String dtel) {
		this.dtel = dtel;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getDtime() {
		return dtime;
	}
	public void setDtime(String dtime) {
		this.dtime = dtime;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getFilename2() {
		return filename2;
	}
	public void setFilename2(String filename2) {
		this.filename2 = filename2;
	}
	public String getFilename3() {
		return filename3;
	}
	public void setFilename3(String filename3) {
		this.filename3 = filename3;
	}
	public String getFilename4() {
		return filename4;
	}
	public void setFilename4(String filename4) {
		this.filename4 = filename4;
	}
	public MultipartFile getAttach1() {
		return attach1;
	}
	public void setAttach1(MultipartFile attach1) {
		this.attach1 = attach1;
	}
	public MultipartFile getAttach2() {
		return attach2;
	}
	public void setAttach2(MultipartFile attach2) {
		this.attach2 = attach2;
	}
	public MultipartFile getAttach3() {
		return attach3;
	}
	public void setAttach3(MultipartFile attach3) {
		this.attach3 = attach3;
	}
	public MultipartFile getAttach4() {
		return attach4;
	}
	public void setAttach4(MultipartFile attach4) {
		this.attach4 = attach4;
	}
	
	
	
	
}
