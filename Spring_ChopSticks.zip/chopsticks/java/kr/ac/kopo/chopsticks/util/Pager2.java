package kr.ac.kopo.chopsticks.util;

public class Pager2 {
	int page = 1;
	final int pager = 5;
	float total;
	
	public String getHtml() {
//		String html = "<tr class=\"pagination\">";
//		
//		int maxPage = (int) Math.ceil(total / pager);
//				
//		html += "<td class=\"page-item\"><a href=\"?page=1\">&laquo;</a></td>";
//		
//		for(int index=1; index <= maxPage; index++) {
//			// <li><a href="?page=1">1<a></li>
//			
//			html += "<td class=\"page-item";
//			
//			if(page == index)
//				html += " active";
//			
//			html += "\"><a href=\"?page=";				
//			html += index;			
//			html += "\">" + index + "</a></td>";
//		}
//		
//		html += "<td class=\"page-item\"><a href=\"?page=" + maxPage + "\">&raquo;</a></td>";
//		
//		html += "</tr>";
//		
//		return html;
		 String html = "";
	      
	      html += "<div>";
	      
	      int maxPage = (int) Math.ceil( total / pager );
	      for(int i=1; i <= maxPage; i++) {
	         //<span><a href="?pager=1">1</a></span>
	         
	         html += "<span><a href=\"?page=" + i;
	         
	         if(search != null && keyword != null) {
	            html += "&search=" + search + "&keyword=" + keyword;
	         }
	         
	         html += "\">" + i;
	         html += "</a></span>";
	      }
	      html += "</div>";
	      
	      return html;
	}
	
	public int getOffset() {
		return (page - 1) * pager;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}
	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	String search;
	String keyword;
}
